
# Telegram Stars Bot UI (Mini‑App)

This is a simple front-end interface for a Telegram bot using the Giftomania-style layout.

## Features
- Shows star balance
- Gift boxes (Bronze, Silver, Gold, Ultimate)
- Withdraw button (with bot integration capability)

## Hosting
Upload this to GitHub and enable GitHub Pages.

## Connect to Telegram
Use `telegram-web-app.js` and a WebApp button to open this from your bot.
