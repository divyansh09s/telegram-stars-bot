
function withdraw() {
  alert("Withdrawal request sent!");
  // You can link this to your Telegram bot using fetch or HTTP.post
}
